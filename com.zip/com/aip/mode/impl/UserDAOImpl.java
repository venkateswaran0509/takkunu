package com.aip.mode.impl;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.aip.model.entity.User;
import com.aip.model.inter.UserDAO;
import com.aip.model.entity.ConnectionFactory;

public  class UserDAOImpl implements UserDAO{
	Connection con=null;
	public UserDAOImpl() {
		con=ConnectionFactory.openConn();
	}

	@Override
	public int addUser(User abc) {
		
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("insert into registration_form values(?,?,?,?,?,?,?,?,?)");
            ps.setString(1,abc.getFirst_name());
            ps.setString(2,abc.getLast_name());
            ps.setInt(3,abc.getAge());
            ps.setString(4,abc.getGender());
            ps.setString(5,abc .getContact_number());
            ps.setString(6,abc.getCity());
            ps.setString(7,abc.getState());
            ps.setString(8,abc.getUser_id());
            ps.setString(9,abc.getPassword());
            status=ps.executeUpdate();

		}catch (Exception e) {
			System.out.println("Error in Insert User "+e);
		}
		return status;
		
	}

	@Override
	public int updateUser(User abc) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("update  registration_form set First_name=?,Last_name=?,Age=?,Gender=?,Contact_number=?,City=?,State=? where User_id=? ");
			ps.setString(1,abc.getFirst_name());
            ps.setString(2,abc.getLast_name());
            ps.setInt(3,abc.getAge());
            ps.setString(4,abc.getGender());
            ps.setString(5,abc.getContact_number());
            ps.setString(6,abc.getCity());
            ps.setString(7,abc.getState());
            ps.setString(8,abc.getUser_id());
            
            
           
            status=ps.executeUpdate();

		}catch (Exception e) {
			System.out.println("Error in Updating User "+e);
		}
		return status;
		
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int deleteUser(String userid) {
		
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("delete from registration_form where User_id=?");
            ps.setString(1,userid);
           
            status=ps.executeUpdate();

		}catch (Exception e) {
			System.out.println("Error in Delete User "+e);
		}
		return status;
	}

	@Override
	public int Userlogin(User abc) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("select User_id,password from registration_form where User_id=?and password=?");
            ps.setString(1,abc.getUser_id());
            ps.setString(2,abc.getPassword());
            ResultSet rs=ps.executeQuery();
          //  status=ps.executeUpdate();
            if(rs.next())
            	status=1;
            else
            	status=0;

		}catch (Exception e) {
			System.out.println("Error in Login User "+e);
		}
		return status;
	}
	
}
