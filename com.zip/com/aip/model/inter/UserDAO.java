package com.aip.model.inter;

import java.util.List;

import com.aip.model.entity.User;


	



	public interface UserDAO {
	                
	                public int addUser(User abc);
	                public int updateUser(User abc);
	                public List<User> getAllUser();
	                public int deleteUser(String User_id);
	                public int Userlogin(User abc);



}
